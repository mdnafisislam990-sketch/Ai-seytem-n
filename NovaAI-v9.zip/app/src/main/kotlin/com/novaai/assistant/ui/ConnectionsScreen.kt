package com.novaai.assistant.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaai.assistant.ai.LlmClient
import com.novaai.assistant.data.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun keyCount(s: String) = s.split(',').count { it.trim().isNotEmpty() }

@Composable
fun ConnectionsScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var gStatus by remember { mutableStateOf<String?>(if (Store.str("k_gemini").isBlank()) null else "Saved") }
    var gMsg by remember { mutableStateOf<String?>(null) }
    var groqN by remember { mutableStateOf(keyCount(Store.str("k_groq"))) }
    var elOn by remember { mutableStateOf(Store.str("k_eleven").isNotBlank()) }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(NovaColors.Card)
                    .border(1.dp, NovaColors.Line, RoundedCornerShape(12.dp)).clickable { onBack() },
                contentAlignment = Alignment.Center
            ) { Text("←", fontSize = 20.sp) }
            Spacer(Modifier.size(14.dp))
            Text("Connections", fontSize = 28.sp)
        }
        Text("Nova talks and chats through your own keys. They are stored only on this phone.", color = NovaColors.TextDim)

        KeyCard(
            "Voice - Gemini key", gStatus, "Powers live voice conversations.", Store.str("k_gemini"),
            "Save Gemini key", "Get a free key at Google AI Studio", "https://aistudio.google.com/apikey", gMsg
        ) { v ->
            Store.put("k_gemini", v.trim())
            if (v.isBlank()) { gStatus = null; gMsg = null } else {
                gStatus = "Checking…"; gMsg = null
                scope.launch {
                    val m = withContext(Dispatchers.IO) { LlmClient.liveModel() }
                    if (m != null) { gStatus = "Verified"; gMsg = "Key is valid. Live voice is available (" + m.removePrefix("models/") + ")." }
                    else { gStatus = "Not verified"; gMsg = "Couldn’t verify this key. Check it and your internet." }
                }
            }
        }
        KeyCard(
            "Chat - Groq keys", if (groqN > 0) "$groqN key" + (if (groqN > 1) "s" else "") + " ready" else null,
            "Fast typed replies. Add several keys, separated by commas - they take turns if one is rate limited.",
            Store.str("k_groq"), "Save Groq keys", "Get a free key at Groq", "https://console.groq.com/keys", null
        ) { v -> Store.put("k_groq", v.trim()); groqN = keyCount(v) }
        KeyCard(
            "Voice - ElevenLabs key (optional)", if (elOn) "Ready" else null,
            "Lets Nova speak chat replies with an ElevenLabs voice instead of Gemini’s own.",
            Store.str("k_eleven"), "Save ElevenLabs key", "Get a key at ElevenLabs", "https://elevenlabs.io/app/settings/api-keys", null
        ) { v -> Store.put("k_eleven", v.trim()); elOn = v.isNotBlank() }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
private fun KeyCard(
    title: String, status: String?, desc: String, initial: String, button: String,
    linkText: String, url: String, message: String?, onSave: (String) -> Unit
) {
    val ctx = LocalContext.current
    var v by remember { mutableStateOf(initial) }
    NovaCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontSize = 18.sp, modifier = Modifier.weight(1f))
                if (status != null) {
                    val ok = status == "Verified" || status == "Ready" || status.endsWith("ready") || status == "Saved"
                    Text("● " + status, color = if (ok) NovaColors.Green else NovaColors.TextDim, fontSize = 13.sp)
                }
            }
            Text(desc, color = NovaColors.TextDim, fontSize = 13.sp)
            OutlinedTextField(
                v, { v = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation(), placeholder = { Text("Paste key here") }
            )
            Button(onClick = { onSave(v) }, modifier = Modifier.fillMaxWidth()) { Text(button) }
            if (message != null) Text(message, color = if (message.startsWith("Key is valid")) NovaColors.Green else Color(0xFFFF8A8A), fontSize = 13.sp)
            Text(
                linkText + " ↗", color = NovaColors.Purple, fontSize = 14.sp,
                modifier = Modifier.clickable { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } }
            )
        }
    }
}
