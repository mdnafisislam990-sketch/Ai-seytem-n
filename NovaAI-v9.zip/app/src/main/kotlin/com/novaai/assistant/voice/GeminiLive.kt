package com.novaai.assistant.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.util.Base64
import com.novaai.assistant.ai.LlmClient
import com.novaai.assistant.assist.IntentRouter
import com.novaai.assistant.assist.Session
import com.novaai.assistant.control.NovaAccessibilityService
import com.novaai.assistant.data.Store
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Real-time voice conversation with Gemini Live: your voice streams up, the voice streams back,
 * and phone actions run through the "phone" tool. This is what makes it feel like a call.
 */
class GeminiLive(
    private val ctx: Context,
    private val onHearing: (Boolean) -> Unit,
    private val onSpeaking: (Boolean) -> Unit,
    private val onBusy: (Boolean) -> Unit,
    private val onUnavailable: () -> Unit,
    private val onFatal: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val http = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(20, TimeUnit.SECONDS).build()
    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile private var ready = false
    @Volatile private var everReady = false
    @Volatile private var gaveUp = false
    @Volatile private var reconnecting = false
    @Volatile private var ws: WebSocket? = null
    @Volatile private var track: AudioTrack? = null
    @Volatile private var playUntil = 0L
    private var tries = 0
    private val q = LinkedBlockingQueue<ByteArray>()
    private var sm: SteadyMic? = null
    private var lastSp = false
    private var player: Thread? = null

    fun start() {
        if (running) return
        running = true; paused = false
        Session.info.value = "Connecting to Gemini Live…"
        startPlayer(); startMic(); connect()
    }

    fun pause() { paused = true; sm?.muted = true; onHearing(false) }
    fun resume() { if (running) { paused = false; sm?.muted = false } }

    fun stop() {
        running = false; ready = false
        runCatching { ws?.close(1000, "bye") }; ws = null
        sm?.stop(); sm = null
        player?.interrupt(); q.clear()
        runCatching { track?.stop() }; runCatching { track?.release() }; track = null
        scope.cancel()
        onHearing(false); onSpeaking(false); onBusy(false)
    }

    private fun connect() {
        Thread {
            val model = LlmClient.liveModel()
            if (model == null) { Session.info.value = "Live: no live voice model found for this key"; unavailable(); return@Thread }
            if (!running) return@Thread
            val key = Store.str("k_gemini").trim()
            val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" + key
            ws = http.newWebSocket(Request.Builder().url(url).build(), listener(model))
        }.start()
    }

    private fun listener(model: String) = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) { Session.info.value = "Live: connected, setting up…"; webSocket.send(setup(model)) }
        override fun onMessage(webSocket: WebSocket, text: String) { handle(text) }
        override fun onMessage(webSocket: WebSocket, bytes: ByteString) { handle(bytes.utf8()) }
        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { Session.info.value = "Live closed ($code) " + reason.take(80); dropped() }
        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { Session.info.value = "Live error: " + (response?.code ?: "") + " " + (t.message ?: "").take(80); dropped() }
    }

    private fun unavailable() {
        if (gaveUp) return
        gaveUp = true
        main.post { onUnavailable() }
    }

    private fun dropped() {
        ready = false
        if (!running || gaveUp) return
        if (!everReady) { unavailable(); return }
        if (reconnecting) return
        reconnecting = true
        tries++
        if (tries > 6) { main.post { onFatal("লাইভ সংযোগ বিচ্ছিন্ন হয়েছে") }; return }
        main.postDelayed({ if (running) connect() }, 1500)
    }

    private fun setup(model: String): String {
        val n = Store.name
        val sys = "You are Nova, a friendly, quick voice assistant on the phone of $n ভাই. Speak Bangla unless he speaks another language, and call him $n ভাই. " +
            "Keep every reply to one or two short sentences. For any phone action (open an app, call, SMS, WhatsApp message, volume, scroll, next or previous video, like, torch, alarm, back, home, screenshot, play or pause music) " +
            "you MUST call the phone function with the request as a short English command such as 'open tiktok', 'call rahim', 'next video', 'volume up', 'alarm 7 am'. " +
            "Only say it is done after the function returns. If he asks what is on the screen, or asks about something he is looking at, call look_at_screen first, then answer from what it returns. Answer other questions normally. Personality: " + Store.str("persona", "Friendly") + "."
        val fn = JSONObject().put("name", "phone").put("description", "Do something on the phone")
            .put("parameters", JSONObject().put("type", "OBJECT")
                .put("properties", JSONObject().put("command", JSONObject().put("type", "STRING").put("description", "Short English command")))
                .put("required", JSONArray().put("command")))
        val gen = JSONObject().put("responseModalities", JSONArray().put("AUDIO")).put("speechConfig",
            JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", Store.str("voice", "Kore")))))
        val setup = JSONObject().put("model", model).put("generationConfig", gen)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", JSONArray().put(fn)
                .put(JSONObject().put("name", "look_at_screen").put("description", "Look at the phone screen right now and read what is on it")))))
        return JSONObject().put("setup", setup).toString()
    }

    private fun handle(text: String) {
        val o = try { JSONObject(text) } catch (e: Exception) { return }
        if (o.has("setupComplete")) { Session.info.value = ""; ready = true; everReady = true; tries = 0; reconnecting = false; return }
        o.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted")) flush()
            val parts = sc.optJSONObject("modelTurn")?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data").orEmpty()
                    if (d.isNotEmpty()) enqueue(Base64.decode(d, Base64.DEFAULT))
                }
            }
        }
        o.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
            for (i in 0 until calls.length()) runTool(calls.getJSONObject(i))
        }
        if (o.has("goAway")) runCatching { ws?.close(1000, "reconnect") }
    }

    private fun runTool(c: JSONObject) {
        val id = c.optString("id")
        val name = c.optString("name", "phone")
        val cmd = c.optJSONObject("args")?.optString("command").orEmpty()
        onBusy(true)
        scope.launch {
            val res = try {
                if (name == "look_at_screen") {
                    val svc = NovaAccessibilityService.instance
                    if (svc == null) "Accessibility is off. Ask the user to turn on Nova AI in Accessibility settings."
                    else {
                        val shot = svc.screenshotJpeg()
                        if (shot != null) {
                            val img = JSONObject().put("data", Base64.encodeToString(shot, Base64.NO_WRAP)).put("mimeType", "image/jpeg")
                            ws?.send(JSONObject().put("realtimeInput", JSONObject().put("video", img)).toString())
                        }
                        "Screen text:\n" + svc.readScreen() + (if (shot != null) "\n(A screenshot was also sent.)" else "")
                    }
                } else {
                    val r = IntentRouter.route(ctx, cmd)
                    if (r.handled) r.reply.ifBlank { "done" } else "not a phone command"
                }
            } catch (e: Exception) { "failed" }
            val fr = JSONObject().put("id", id).put("name", name).put("response", JSONObject().put("result", res))
            ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", JSONArray().put(fr))).toString())
            onBusy(false)
        }
    }

    private fun enqueue(b: ByteArray) {
        playUntil = maxOf(playUntil, System.currentTimeMillis()) + b.size / 48L // 24 kHz * 2 bytes = 48 bytes per ms
        q.offer(b)
    }

    private fun flush() {
        q.clear(); playUntil = 0
        runCatching { track?.pause(); track?.flush(); track?.play() }
    }

    private fun startPlayer() {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val tr = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, 48000))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        tr.play()
        track = tr
        player = Thread {
            try { while (running) { val b = q.take(); tr.write(b, 0, b.size) } } catch (e: Exception) { }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun startMic() {
        val m = SteadyMic(ctx, { b, n -> frame(b, n) }, { msg -> main.post { onFatal(msg) } })
        sm = m
        m.start(true)
    }

    private fun frame(buf: ShortArray, n: Int) {
        val sp = System.currentTimeMillis() < playUntil + 250
        if (sp != lastSp) { lastSp = sp; onSpeaking(sp) }
        if (!ready || paused) return
        var sum = 0.0
        for (i in 0 until n) sum += buf[i].toDouble() * buf[i]
        val rms = Math.sqrt(sum / n)
        // While Nova talks, only a clearly louder voice (you) goes through, so you can interrupt but it won't hear itself.
        if (sp && rms < 2200) return
        onHearing(rms > 900)
        val bb = java.nio.ByteBuffer.allocate(n * 2).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until n) bb.putShort(buf[i])
        val audio = JSONObject().put("data", Base64.encodeToString(bb.array(), Base64.NO_WRAP)).put("mimeType", "audio/pcm;rate=16000")
        ws?.send(JSONObject().put("realtimeInput", JSONObject().put("audio", audio)).toString())
    }
}
