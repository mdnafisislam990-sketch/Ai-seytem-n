package com.novaai.assistant.assist

import android.content.Context
import com.novaai.assistant.control.Cmd
import com.novaai.assistant.control.DeviceActions
import com.novaai.assistant.control.Executor
import com.novaai.assistant.data.Repo
import com.novaai.assistant.data.Store

data class Routed(
    val handled: Boolean,
    val reply: String = "",
    val close: Boolean = false,
    val searchQuery: String? = null,
    val quiet: Boolean = false
)

object IntentRouter {
    private fun has(t: String, vararg k: String) = k.any { t.contains(it) }

    private fun bnDigits(s: String): String {
        val sb = StringBuilder()
        for (c in s) sb.append(if (c in '\u09E6'..'\u09EF') ('0' + (c - '\u09E6')) else c)
        return sb.toString()
    }

    private val stop = setOf("open", "launch", "ওপেন", "খোলো", "খোল", "করো", "কর", "চালু", "চালাও", "দাও", "the", "app", "অ্যাপ", "টা")

    suspend fun route(ctx: Context, raw: String): Routed {
        val t = bnDigits(raw).lowercase().trim().trimEnd('.', '।', '!', '?')

        if (has(t, "goodbye", "good bye", "bye nova", "bye bye", "বিদায়", "টা টা"))
            return Routed(true, "বিদায় ${Store.name} ভাই, দরকার হলে ডাকবেন", close = true)

        val mem = has(t, "memory", "ram", "মেমরি", "মেমোরি", "র‍্যাম", "ব্যাকগ্রাউন্ড", "background")
        val clr = has(t, "clear", "clean", "free", "পরিষ্কার", "ক্লিয়ার", "খালি", "মুছ")
        if (mem && clr) return Routed(true, DeviceActions.clearBackground(ctx))

        if (has(t, "alarm", "অ্যালার্ম", "এলার্ম", "অ্যালারাম"))
            return Routed(true, DeviceActions.setAlarmFromText(ctx, t))

        Regex("^(?:remind me to|remind me|reminder|add task)\\s+(.+)$").find(t)?.let {
            Repo.addTask(it.groupValues[1]); return Routed(true, "রিমাইন্ডার যোগ করলাম: ${it.groupValues[1]}")
        }
        Regex("^(.+?)\\s*(?:মনে করিয়ে দাও|মনে করাও)$").find(t)?.let {
            Repo.addTask(it.groupValues[1]); return Routed(true, "রিমাইন্ডার যোগ করলাম: ${it.groupValues[1]}")
        }

        val sq = Regex("^(?:google search|search for|search|google|সার্চ)\\s+(.+)$").find(t)?.groupValues?.get(1)
            ?: Regex("^(.+?)\\s*(?:সার্চ করো|সার্চ কর|গুগলে খোঁজো|গুগলে সার্চ করো)$").find(t)?.groupValues?.get(1)
        if (sq != null) return Routed(true, "গুগলে সার্চ করছি, ${Store.name} ভাই", searchQuery = sq)

        val cmd = parse(t) ?: return Routed(false)
        val r = Executor.run(ctx, cmd)
        return Routed(true, r.reply, close = r.close, quiet = r.quiet)
    }

    /** Turns a spoken sentence (Bangla or English) into a phone command, or null if it's just chat. */
    private fun parse(t: String): Cmd? {
        val words = t.split(" ").filter { it.isNotBlank() }
        val n = words.size

        // --- mic ---
        if (has(t, "stop listening", "mic off", "turn off mic", "মাইক বন্ধ", "মাইক অফ", "শোনা বন্ধ")) return Cmd.StopMic

        // --- scrolling (TikTok, Reels, Shorts, any page) ---
        if (has(t, "stop scroll", "stop auto", "স্ক্রল বন্ধ", "স্ক্রল থামাও", "অটো স্ক্রল বন্ধ") ||
            (n <= 2 && has(t, "stop", "থামো", "থাম", "স্টপ", "বন্ধ করো")))
            return Cmd.StopScroll
        if (has(t, "auto scroll", "autoscroll", "অটো স্ক্রল", "অটোস্ক্রল", "অটো স্কল")) {
            val sec = Regex("(\\d{1,3})").find(t)?.groupValues?.get(1)?.toIntOrNull() ?: 8
            return Cmd.AutoScroll(sec.coerceIn(2, 120))
        }
        if (has(t, "next song", "next track", "পরের গান")) return Cmd.Media("next")
        if (has(t, "previous song", "last song", "আগের গান")) return Cmd.Media("prev")
        if (n <= 4 && has(t, "previous", "scroll up", "go up", "আগের", "প্রিভিয়াস", "উপরে", "পিছনের ভিডিও")) return Cmd.Scroll(false)
        if (n <= 4 && has(t, "next video", "scroll down", "scroll", "next", "পরের", "নেক্সট", "স্ক্রল", "নিচে", "সামনে")) return Cmd.Scroll(true)
        if (n <= 2 && has(t, "like", "লাইক")) return Cmd.Like

        // --- phone buttons ---
        if (n <= 3 && has(t, "screenshot", "স্ক্রিনশট")) return Cmd.Nav("screenshot")
        if (n <= 3 && has(t, "lock screen", "lock phone", "স্ক্রিন লক", "ফোন লক")) return Cmd.Nav("lock")
        if (n <= 3 && has(t, "recent", "রিসেন্ট")) return Cmd.Nav("recents")
        if (n <= 3 && has(t, "notification", "নোটিফিকেশন")) return Cmd.Nav("notifications")
        if (n <= 3 && has(t, "quick settings", "কুইক সেটিংস")) return Cmd.Nav("quick")
        if (n <= 3 && has(t, "go home", "home", "হোম")) return Cmd.Nav("home")
        if (n <= 3 && has(t, "go back", "back", "পিছনে", "ফিরে যাও", "ব্যাক")) return Cmd.Nav("back")

        // --- calls ---
        if (has(t, "answer call", "pick up", "accept call", "ফোন ধরো", "কল ধরো", "কল রিসিভ")) return Cmd.Answer
        if (has(t, "end call", "hang up", "reject call", "decline call", "কল কাটো", "কল কেটে", "ফোন কাটো", "ফোন কেটে")) return Cmd.HangUp

        // --- messages ---
        val waEn = Regex("whatsapp(?: message)?(?: to)?\\s+(.+?)\\s+(?:saying|say|that|:)\\s+(.+)").find(t)
        if (waEn != null) return Cmd.WhatsApp(waEn.groupValues[1].trim(), waEn.groupValues[2].trim())
        val waBn = Regex("^(.+?)\\s*কে\\s*(?:হোয়াটসঅ্যাপে|হোয়াটসঅ্যাপ|হোয়াটস অ্যাপে|whatsapp)\\s*(?:এ\\s*)?(?:মেসেজ\\s*)?(?:পাঠাও|দাও|করো|কর)?[,:]?\\s*(.+)$").find(t)
        if (waBn != null) return Cmd.WhatsApp(waBn.groupValues[1].trim(), waBn.groupValues[2].trim())
        val smsEn = Regex("(?:send )?(?:an? )?(?:sms|text|message)(?: to)?\\s+(.+?)\\s+(?:saying|say|that|:)\\s+(.+)").find(t)
        if (smsEn != null) return Cmd.Sms(smsEn.groupValues[1].trim(), smsEn.groupValues[2].trim())
        val smsBn = Regex("^(.+?)\\s*কে\\s*(?:মেসেজ|এসএমএস|sms)\\s*(?:পাঠাও|দাও|করো|কর)?[,:]?\\s*(.+)$").find(t)
        if (smsBn != null) return Cmd.Sms(smsBn.groupValues[1].trim(), smsBn.groupValues[2].trim())

        Regex("^(?:call|phone|dial)\\s+(.+)$").find(t)?.let { return Cmd.Call(it.groupValues[1].trim()) }
        Regex("^(.+?)\\s*(?:কে|এর নম্বরে)\\s*(?:ফোন|কল)\\s*(?:করো|কর|দাও)$").find(t)?.let { return Cmd.Call(it.groupValues[1].trim()) }
        Regex("^(?:ফোন|কল)\\s*(?:করো|কর|দাও)\\s+(.+?)(?:\\s*কে)?$").find(t)?.let { return Cmd.Call(it.groupValues[1].trim()) }

        // --- touch the screen ---
        Regex("^(?:click|tap|press)(?: on)?\\s+(.+)$").find(t)?.let { return Cmd.Tap(it.groupValues[1].trim()) }
        Regex("^(.+?)\\s*(?:এ|তে)?\\s*(?:ক্লিক|ট্যাপ|চাপ)\\s*(?:করো|কর|দাও)?$").find(t)?.let { return Cmd.Tap(it.groupValues[1].trim()) }
        Regex("^type\\s+(.+)$").find(t)?.let { return Cmd.Type(it.groupValues[1].trim()) }
        Regex("^(.+?)\\s*টাইপ করো$").find(t)?.let { return Cmd.Type(it.groupValues[1].trim()) }

        // --- sound, hardware ---
        if (has(t, "volume up", "louder", "ভলিউম বাড়াও", "আওয়াজ বাড়াও", "ভলিউম বাড়ান")) return Cmd.Volume("up")
        if (has(t, "volume down", "quieter", "ভলিউম কমাও", "আওয়াজ কমাও", "ভলিউম কমান")) return Cmd.Volume("down")
        if (n <= 2 && has(t, "mute", "মিউট")) return Cmd.Volume("mute")
        if (has(t, "play music", "play song", "resume music", "গান চালাও")) return Cmd.Media("play")
        if (has(t, "pause music", "pause song", "গান থামাও", "গান বন্ধ")) return Cmd.Media("pause")
        if (has(t, "flashlight", "torch", "ফ্ল্যাশলাইট", "টর্চ"))
            return Cmd.Torch(!has(t, " off", "বন্ধ", "অফ", "নিভাও"))
        if (has(t, "wifi", "wi-fi", "ওয়াইফাই")) return Cmd.Panel("wifi")
        if (has(t, "bluetooth", "ব্লুটুথ")) return Cmd.Panel("bluetooth")
        if (has(t, "airplane", "flight mode", "ফ্লাইট মোড")) return Cmd.Panel("airplane")
        if (n <= 3 && has(t, "settings", "সেটিংস")) return Cmd.Panel("settings")
        if (has(t, "what time", "time now", "সময় কত", "কয়টা বাজে")) return Cmd.Time

        // --- open an app ---
        val openWord = has(t, "open", "launch", "ওপেন", "খোল", "চালু", "চালাও")
        if (openWord && n <= 5) {
            val name = words.filter { it !in stop }.joinToString(" ").trim()
            if (name.isNotEmpty()) return Cmd.OpenApp(name)
        }
        return null
    }
}
